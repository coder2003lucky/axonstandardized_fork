stimdel= "soma" 
stimdur = 0.5 
