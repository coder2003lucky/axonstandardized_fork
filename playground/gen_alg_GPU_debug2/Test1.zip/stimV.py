stimdel= 10 
stimdur = 100 
stimamp = 0.5 
stimloc = 0.5 
