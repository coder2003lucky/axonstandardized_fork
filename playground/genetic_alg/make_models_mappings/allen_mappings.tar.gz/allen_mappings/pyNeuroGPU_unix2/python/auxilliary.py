class Aux:
	pass