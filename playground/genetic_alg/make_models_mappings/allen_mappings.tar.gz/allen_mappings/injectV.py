stimcomp =
stimloc = 
stimarea = 